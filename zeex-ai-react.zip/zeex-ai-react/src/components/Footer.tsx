import React from 'react';
import "./Footer.css";

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-content">
          <div className="footer-brand">
            <div className="brand-logo">
              <div className="logo-icon">Z</div>
              <span className="logo-text">ZeexAI</span>
            </div>
            <p className="brand-description">
              Harnessing the power of data and artificial intelligence to predict risks, 
              ensure safety, and optimize daily operations.
            </p>
          </div>

          <div className="footer-links">
            <h3 className="links-title">Solutions</h3>
            <ul className="links-list">
              <li><a href="#" className="footer-link">Threat Detection</a></li>
              <li><a href="#" className="footer-link">Surveillance Analytics</a></li>
              <li><a href="#" className="footer-link">Alert Systems</a></li>
              <li><a href="#" className="footer-link">Mobile Services</a></li>
            </ul>
          </div>

          <div className="footer-links">
            <h3 className="links-title">Company</h3>
            <ul className="links-list">
              <li><a href="#" className="footer-link">About Us</a></li>
              <li><a href="#" className="footer-link">Careers</a></li>
              <li><a href="#" className="footer-link">Contact</a></li>
              <li><a href="#" className="footer-link">Blog</a></li>
            </ul>
          </div>

          <div className="footer-contact">
            <h3 className="links-title">Contact</h3>
            <div className="contact-info">
              <div className="contact-item">
                <span className="contact-icon">📧</span>
                <a href="mailto:admin@zeexai.com" className="footer-link">admin@zeexai.com</a>
              </div>
              <div className="contact-item">
                <span className="contact-icon">📞</span>
                <a href="tel:+918709221636" className="footer-link">+91 8709221636</a>
              </div>
              <div className="contact-item">
                <span className="contact-icon">📍</span>
                <span>IIT Madras, Chennai</span>
              </div>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <div className="copyright">
            © {currentYear} ZeexAI. All rights reserved.
          </div>
          <div className="legal-links">
            <a href="#" className="legal-link">Privacy Policy</a>
            <a href="#" className="legal-link">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;