import React from 'react';
import SolutionsGrid from './SolutionsGrid';
import Industries from './Industries';
import TechDeepDive from './TechDeepDive';
import Testimonials from './Testimonials';
import CTA from './CTA';
import "./SolutionsPage.css";

const SolutionsPage: React.FC = () => {
  return (
    <div className="solutions-page">
      {/* Hero Section */}
      <section className="solutions-hero">
        <div className="hero-container">
          <div className="hero-content">
            <h1 className="hero-title">
              Advanced <span className="gradient-text">AI Security</span> Solutions
            </h1>
            <p className="hero-description">
              Comprehensive AI-powered security solutions designed to protect your assets 
              and provide enterprise-grade peace of mind with cutting-edge technology.
            </p>
            <div className="hero-stats">
              <div className="stat">
                <div className="stat-number">99.9%</div>
                <div className="stat-label">Uptime</div>
              </div>
              <div className="stat">
                <div className="stat-number">50ms</div>
                <div className="stat-label">Response Time</div>
              </div>
              <div className="stat">
                <div className="stat-number">24/7</div>
                <div className="stat-label">Monitoring</div>
              </div>
            </div>
            <button className="hero-cta">
              Request Security Audit
              <span className="cta-arrow">→</span>
            </button>
          </div>
          <div className="hero-visual">
            <div className="floating-elements">
              <div className="floating-element element-1"></div>
              <div className="floating-element element-2"></div>
              <div className="floating-element element-3"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Use your existing components */}
      <SolutionsGrid />
      <Industries />
      <TechDeepDive />
      <Testimonials />
      <CTA />
    </div>
  );
};

export default SolutionsPage;