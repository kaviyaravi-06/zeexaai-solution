import React, { useState } from 'react';
import "./Header.css";

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="header">
      <div className="header-container">
        <div className="logo">
          <div className="logo-icon">Z</div>
          <span className="logo-text">ZeexAI</span>
        </div>
        
        <nav className={`nav ${isMenuOpen ? 'nav-open' : ''}`}>
          <a href="/" className="nav-link">Home</a>
          <a href="/solutions" className="nav-link active">Solutions</a>
          <a href="/industries" className="nav-link">Industries</a>
          <a href="/about" className="nav-link">About</a>
          <a href="/contact" className="nav-link">Contact</a>
        </nav>

        <div className="header-actions">
          <button className="login-btn">Login</button>
          <button className="demo-btn">Request Demo</button>
        </div>

        <button 
          className="mobile-menu-btn"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </header>
  );
};

export default Header;